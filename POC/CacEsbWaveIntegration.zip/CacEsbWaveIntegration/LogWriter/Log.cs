﻿using System;

namespace LogWriter
{
    public class Log
    {

    }
}
