﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CacHttpClient;

namespace CacEsbRequestMsgProcessor.Controllers
{
    [Route("api/MessageProcessor")]
    public class CacMsgProcessorController : Controller
    {
        private IRestClient restClient;

        public CacMsgProcessorController()
        {
            
        }

        [HttpGet("Ping")]
        public string Ping()
        {
            return "Pong";
        }

        [HttpPost("ListenCACMessage")]
        public StatusCodeResult ListenCACMessage()
        {
            //TODO: 
            //1) Validating Message
            //2) Logging All Transactions and Errors in each steps
            //3) Call CN API (Use Wrapper Http Client Class Library)
            //4) Call Change Status API (Use Wrapper Http Client Class Library)
            //5) Publish to ReqSQ Topic | If we are using ESB Publisher then create a Wrapper class Library for Publisher or else Use the Http Client Wrapper)
            //6) Publish to FilePath Topic | If we are using ESB Publisher then create a Wrapper class Library for Publisher or else Use the Http Client Wrapper)
            return Ok();
        }
    }
}