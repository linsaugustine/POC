﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CacHttpClient
{
    public interface IRestClient
    {
        void PostAsync();
    }
}
