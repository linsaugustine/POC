﻿using System;

namespace CacHttpClient
{
    public class RestClient : IRestClient
    {
        public void PostAsync()
        {

        }
    }
}
